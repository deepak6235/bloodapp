const mongoose = require('mongoose')

const DonorSchema = new mongoose.Schema({
    dname: String,
    dage: String,
    dblood: String,
   
    demail:String,
    dphone:String
   
   
    
})

const DonorModel = mongoose.model("donor", DonorSchema)
module.exports = DonorModel