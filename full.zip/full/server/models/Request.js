const mongoose = require('mongoose')

const RequestSchema = new mongoose.Schema({
   
    rname:String,
    rage:String,
    rblood:String,
  
    remail:String,
    rphone:String

   
    
})

const RequestModel = mongoose.model("request", RequestSchema)
module.exports = RequestModel