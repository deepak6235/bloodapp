const express = require("express")
const mongoose = require('mongoose')
const cors = require("cors")

const AdminModel = require('./models/Admin')
const RequestModel =require('./models/Request')
const DonorModel =require('./models/donor')
const UserModel =require('./models/User')
const app = express()
app.use(express.json())
app.use(cors())

mongoose.connect("mongodb://127.0.0.1:27017/emp");




//user login



app.post("/login", (req, res) => {
    const {email, password} = req.body;
    UserModel.findOne({email:email})
    .then(user => {
        if(user) {
            if(user.password === password) {
                res.json("Success")
                
                
            } else {
                res.json("the password is incorrect")

            }
        } else {
            res.json("No record existed")
        }
    })
})





//user register



app.post('/register', (req, res) => {
    UserModel.create(req.body)
    .then(user => res.json(user))
   
    .catch(err => res.json(err))
   

})




//admin login



app.post("/adlogin", (req, res) => {
    const {id, password} = req.body;
    AdminModel.findOne({id : id})
    .then(admin => {
        if(admin) {
            if(admin.password === password) {
                res.json("Success")
            } else {
                res.json("the password is incorrect")

            }
        } else {
            res.json("No admin existed")
        }
    })
})



// admin register



app.post('/adregister', (req, res) => {
    AdminModel.create(req.body)
    .then(admin => res.json(admin))
    
    .catch(err => res.json(err))
   

})





//users blood donate form


app.post("/donor", async (req, res) => {
    try {
      await DonorModel(req.body).save();0
      res.send({ message: "Data added!!" });
    } 
    catch (error) {
      console.log(error);
    }
  });

// to update donor details
app.put("/dedit/:id", async (req, res) => {
    try {
      var data = await DonorModel.findByIdAndUpdate(req.params.id, req.body);
      res.send({message:'updated successfully',data})
    } catch (error) {
      console.log(error)
    }
  });


  // api to view donor list data from db


  app.get("/viewdonor", async (req, res) => {
    try {
      var data = await DonorModel.find();
      res.send(data);
    } catch (error) {
      console.log(error);
    }
  });

    // Deleting a data from donor list




    app.delete('/removedonor/:id',async(req,res)=>{
        console.log(req.params);
        let id = req.params.id
        await DonorModel.findByIdAndDelete(id);
        res.send("Deleted")
      
      })


   



  // to update data from donor list

app.put("/dedit/:id", async (req, res) => {
    try {
      var data = await DonorModel.findByIdAndUpdate(req.params.id, req.body);
      res.send({message:'updated successfully',data})
    } catch (error) {
      console.log(error)
    }
  });






// request side




// user request list
app.post("/addr", async (req, res) => {
    try {
      await RequestModel(req.body).save();0
      res.send({ message: "Data added!!" });
    } 
    catch (error) {
      console.log(error);
    }
  });




    // admin request list view 
app.get("/viewr", async (req, res) => {
    try {
      var data = await RequestModel.find();
      res.send(data);
    } catch (error) {
      console.log(error);
    }
  });


// to delete admin request list 
app.delete("/remover/:id", async (req, res) => {
    try {
       await RequestModel.findByIdAndDelete(req.params.id)
       res.send({message:"Deleted successfully!!!"})
    } catch (error) {
        console.log(error)
    }
});


// to update request list
app.put("/redit/:id", async (req, res) => {
    try {
      var data = await RequestModel.findByIdAndUpdate(req.params.id, req.body);
      res.send({message:'updated successfully',data})
    } catch (error) {
      console.log(error)
    }
  });



app.listen(3002, () => {
    console.log("connected to server")
})


