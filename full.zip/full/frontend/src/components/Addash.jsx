import {
  Button,
  Card,
  CardActions,
  CardContent,
  Grid,
  Typography,
} from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {Link} from 'react-router-dom';


const Addash = () => {
  

  var [rq, setRq] = useState([]);
  var navigate = useNavigate();
  useEffect(() => {
    axios
      .get("http://localhost:3002/viewr")
      .then((res) => {
        console.log(res);
        setRq(res.data);
      })
      .catch((err) => console.log(err));
  }, []);

  const delValue = (id) => {
    console.log(id);
    axios
      .delete("http://localhost:3002/remover/" + id)
      .then((res) => {
        alert(res.data.message);
        window.location.reload();
      })
      .catch((err) => console.log(err));
  };

  const updateValue = (val) => {
    console.log("up clicked");
    navigate("/adupdater", { state: { val } });
  };




  return (
    
    <div style={{ margin: "2%" }}>
  <h2>Request List</h2><br></br>
      <Grid container spacing={2}>
        {rq.map((val, i) => {
          return (
            <Grid item xs={12} md={4}>
              <Card sx={{ minWidth: 275 }} key={i}>
                <CardContent>
                  <Typography
                    sx={{ fontSize: 14 }}
                    color="text.secondary"
                    gutterBottom
                  >
                    Name:{val.rname}
                  </Typography>
                  <Typography sx={{ mb: 1.5 }} color="text.secondary">
                    Age:{val.rage}
                  </Typography>
                  <Typography sx={{ mb: 1.5 }} color="text.secondary">
                    Email Id:{val.remail}
                  </Typography>
                  <Typography sx={{ mb: 1.5 }} color="text.secondary">
                    Phone No.:{val.rphone}
                  </Typography>
                  <Typography sx={{ mb: 1.5 }} color="text.secondary">
                    Blood Group:{val.rblood}
                  </Typography>
                
                </CardContent>
                <CardActions> 
                <Button variant="contained" color="error"
                    size="small"
                    onClick={() => {
                      delValue(val._id);
                    }}
                  >
                    Delete
                  </Button>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <Button variant="contained" color="primary"
                    size="small"
                    onClick={() => {
                      updateValue(val);
                    }}
                  >
                    Update
                  </Button>
           
                 
                </CardActions>
              </Card>
            </Grid>
          );
        })}
      </Grid><br></br><br></br><br></br><br></br>
      <Link to="/adaddreq" className="btn btn-default border  rounded-50 text-decoration-none ">
        Add Request
        </Link>

     

        &nbsp; &nbsp;
        <Link to="/adminview" className="btn btn-default border  rounded-50 text-decoration-none ">
        Back
        </Link>




    </div>
  );
};

      

export default Addash