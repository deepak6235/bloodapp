import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

function Adsign  ()  {
    const [name, setName] = useState()
    const [id, setId] = useState()
    const [password, setPassword] = useState()
    const navigate = useNavigate()


    const handleSubmit = (e) => {
        e.preventDefault()
        axios.post('http://localhost:3002/adregister', {name, id, password})
        .then(result => {console.log(result)
        navigate('/adlogin')
         })
        .catch(err=> console.log(err))
        
       
    }


  return (
    <div className="d-flex justify-content-center align-items-center bg-secondary vh-100">
            <div className="bg-white p-5 rounded w-25">
                <h2>Admin Registration</h2><br></br>
                <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label htmlfor="email">
                            <strong>Name</strong>
                            </label>
                            <input
                            type="text"
                            placeholder="Enter Name"
                            autoComplete="off"
                            name="email"
                            className="form-control rounded-0"
                            onChange={(e) => setName(e.target.value)}
                            />
        </div>
        <div className="mb-3">
            <label htmlFor="email">
                <strong>Admin Id</strong>
            </label>
            <input
            type="text"
            placeholder="Enter Id"
            autoComplete="off"
            name="id"
            className="form-control rounded-0"
            onChange={(e) => setId(e.target.value)}
            />
        </div>
        <div className="mb-3">
            <label htmlFor="email">
                <strong>Password</strong>
            </label>
            <input
            type="password"
            placeholder="Enter Password"
            name="password"
            className="form-control rounded-0"
            onChange={(e) => setPassword(e.target.value)}
            />
        </div>
        <button type="submit" className="btn btn-success w-100 rounded-0">
            Register
        </button>
        </form><br></br>
        <p>Already Have an Account?</p>
 

        <Link to="/adlogin" className="btn btn-default border w-100 bg-light rounded-0 text-decoration-none">
            Admin Login
        </Link><br></br>
        <br></br>
        <Link to="/sign" className="btn btn-default border w-100 bg-light rounded-0 text-decoration-none">
            User 
        </Link>

        </div>
        
      </div>
  )
}

export default Adsign