import React from 'react'
import { Link ,useLocation} from 'react-router-dom'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Button, CardActionArea, CardActions } from '@mui/material';

import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import A_img from "./img/admn2.jpg"

import R_img from "./img/request.jpg"
import D_img from "./img/donorsl.jpg"


const Adminview = () => {

  // const location=useLocation()

  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  }));

  return (


<div style ={{paddingTop:"80px",paddingBottom:"80px"}}>
  


  <Box sx={{ flexGrow: 1 }}>
        <Grid container spacing={2}>
          <Grid item xs={4}>
            <Item>
            <CardMedia
                    component="img"
                    height="400"
                    image={R_img}
                    alt="green iguana"
                  />
            <Typography gutterBottom variant="h5" component="div">
              Request List
            </Typography>
            <Typography variant="body2" color="text.secondary">
            Someone is needing Blood somewhere.
            </Typography>
            <br></br>
        
          <Button> <Link to="/addash" className="btn btn-default border  rounded-50 text-decoration-none">
            Request List
        </Link>
            
          </Button><br></br><br></br>
  
            </Item>
          </Grid>
          <Grid item xs={4}>
            <Item>
  
            <CardMedia
                    component="img"
                    height="412"
                    image={D_img}
                    alt="green iguana"
                  />
            <Typography gutterBottom variant="h5" component="div">
              Donate List
            </Typography>
  
            <Typography variant="body2" color="text.secondary">
            Someone is willing to Donate Blood Somewhere
       
            </Typography>
            <br></br>
            <Link to="/admindonor" className="btn btn-default border  rounded-50 text-decoration-none">
          DONATE LIST
        </Link>
        <br></br><br></br>
            </Item>
          </Grid>
          <Grid item xs={4}>
            <Item>
            <CardMedia
                    component="img"
                    height="302"
                    image={A_img}
                    alt="green iguana"
                  /><br></br><br></br><br></br><br></br>
                  <Typography><h5>
{/* Admin Id:  {location.state.id} */}


</h5></Typography><br></br><br></br><br></br><br></br>
  <Button variant='contained' color='error'>
            <Link to="/adlogin"  className="  rounded-50 text-decoration-none"  color='success'>
            LogOut
        </Link> 
        </Button>
        <br></br><br></br>
            </Item>
          </Grid>
        
        </Grid>
      </Box>
        
   
   
      </div>

  )
}

export default Adminview

    