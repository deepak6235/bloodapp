import { Button, TextField } from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";
import {  useLocation, useNavigate } from "react-router-dom";


const Donor = () => {


  var [inputs, setInputs] = useState({ dname: "", dage: "", demail: "", dphone: "",dblood: "" });
  var location = useLocation();
  var navigate = useNavigate()
  console.log("loc", location.state);

  const inputHandler = (e) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
    console.log(inputs);
  };

  const addHandler = () => {
    console.log("clicked");
    if (location.state !== null) {
      axios
        .put("http://localhost:3002/dedit/"+location.state.val._id,inputs)
        .then((res) => {
            alert(res.data.message)
            navigate('/userview')
            
        })
        .catch((err) => console.log(err));
    }else{
        axios
        .post("http://localhost:3002/donor", inputs)
        .then((res) => {
          console.log(res);
          alert(res.data.message);
          navigate('/userview')
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };



  return (
  

    <div style={{ marginTop: "3%", textAlign: "center" }}>
      <h1>Donate Form</h1><br></br>
    <TextField
      variant="outlined"
      label="Name"
      onChange={inputHandler}
      name="dname"
      value={inputs.dname}
    />
    <br />
    <br />
    <TextField
      variant="outlined"
      label="Age"
      onChange={inputHandler}
      name="dage"
      value={inputs.dage}
    />
    
    <br />
    <br />
    <TextField
      variant="outlined"
      label="Email Id"
      onChange={inputHandler}
      name="demail"
      value={inputs.demail}
    />
    <br />
    <br />
    <TextField
      variant="outlined"
      label="Phone Number"
      onChange={inputHandler}
      name="dphone"
      value={inputs.dphone}
    />
    <br />
    <br />

    <TextField
      variant="outlined"
      label="Blood Group"
      onChange={inputHandler}
      name="dblood"
      value={inputs.dblood}
    />
    <br />
    <br />
  
    <Button variant="contained" color="success" onClick={addHandler}>
      Submit
    </Button>
  </div>
);
};

export default Donor