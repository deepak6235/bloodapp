import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';


import { Link } from 'react-router-dom';
import blood_icon from './img/blood.png.png'

export default function ButtonAppBar() {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static" color='error'>
        <Toolbar>
        <img src={blood_icon} alt="" height="60px" Width="60px"/>
       
          <Typography className='d-flex justify-content-center align-items-center' variant="h4" color="#FFF" component="div" sx={{ flexGrow: 10 }}>
         <b>   Blood Zone</b>
         
            
        
        
          </Typography>
        
          <Link to="/" className="btn btn-default border  rounded-50 text-decoration-none">
            Home
        </Link> &nbsp;
          
          
          <Link to="/sign" className="btn btn-default border rounded-100 text-decoration-none">
            SignUp/Login
        </Link>&nbsp;
        
        </Toolbar>
      </AppBar>
    </Box>
  );
}