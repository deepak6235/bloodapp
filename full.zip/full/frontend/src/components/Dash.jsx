import { Button, TextField } from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";
import {  useLocation, useNavigate } from "react-router-dom";



const AddEmployee = () => {
  var [inputs, setInputs] = useState({ rname: "", rage: "", rblood: "", remail: "" , rphone: ""});
  var location = useLocation();
  var navigate = useNavigate()
  console.log("loc", location.state);

  const inputHandler = (e) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
    console.log(inputs);
  };

  const addHandler = () => {
    console.log("clicked");
    if (location.state !== null) {
      axios
        .put("http://localhost:3002/redit/"+location.state.val._id,inputs)
        .then((res) => {
            alert(res.data.message)
            navigate('/userview')
            
        })
        .catch((err) => console.log(err));
    }else{
        axios
        .post("http://localhost:3002/addr", inputs)
        .then((res) => {
          console.log(res);
          alert(res.data.message);
          navigate('/userview')
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };
  useEffect(() => {
    if (location.state !== null) {
      setInputs({
        ...inputs,
        rname: location.state.val.name,
        rage: location.state.val.age,
        rblood: location.state.val.blood,
        rphone: location.state.val.phone,
        remail: location.state.val.email,
      });
    }
  }, []);
  return (
    <div style={{ marginTop: "3%", textAlign: "center" }}>
    <h1>Request Form</h1><br></br>
  <TextField
    variant="outlined"
    label="Name"
    onChange={inputHandler}
    name="rname"
    value={inputs.rname}
  />
  <br />
  <br />
  <TextField
    variant="outlined"
    label="Age"
    onChange={inputHandler}
    name="rage"
    value={inputs.rage}
  />
  <br />
  <br />
  <TextField
    variant="outlined"
    label="Email Id"
    onChange={inputHandler}
    name="remail"
    value={inputs.remail}
  />
  <br />
  <br />
  <TextField
    variant="outlined"
    label="Phone Number"
    onChange={inputHandler}
    name="rphone"
    value={inputs.rphone}
  />
  <br />
  <br />
  <TextField
    variant="outlined"
    label="Blood Group"
    onChange={inputHandler}
    name="rblood"
    value={inputs.rblood}
  />
  <br />
  <br />

  <Button variant="contained" color="success" onClick={addHandler}>
    Request
  </Button>
</div>
);
};

export default AddEmployee