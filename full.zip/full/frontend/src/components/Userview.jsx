import React from 'react'
import { Link , useLocation } from 'react-router-dom'

import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Button } from '@mui/material';
import B_img from "./img/bneed.jpg"
import B_iimg from "./img/donor.jpg"
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import U_img from "./img/user.jpg"
import D_img from "./img/donor3.png"


const Userview = () => {
  // const location=useLocation()

  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  }));


  return (

  
    <div style ={{paddingTop:"80px",paddingBottom:"80px"}}>
  


<Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        <Grid item xs={4}>
          <Item>
          <CardMedia
         
                  component="img"
                  height="400"
                  image={B_img}
                  alt="green iguana"
                />
          <Typography gutterBottom variant="h5" component="div">
            Request Blood
          </Typography>
          <Typography variant="body2" color="text.secondary">
          A bottle of blood saved my life. Was it yours?
          </Typography>
          <br></br>
      
        <Button> <Link to="/dash" className="btn btn-default border  rounded-50 text-decoration-none">Request</Link>
          
        </Button>
        <br></br><br></br><br></br>
          </Item>
        </Grid>
        <Grid item xs={4}>
          <Item>

          <CardMedia
                  component="img"
                  height="412"
                  image={B_iimg}
                  alt="green iguana"
                />
          <Typography gutterBottom variant="h5" component="div">
            Donate Blood
          </Typography>

          <Typography variant="body2" color="text.secondary">
          Someone is needing Blood somewhere.
          </Typography>
          <br></br>
          <Link to="/donor" className="btn btn-default border  rounded-50 text-decoration-none">
         DONATE
        </Link> 
        <br></br><br></br><br></br>


          </Item>
        </Grid>



        <Grid item xs={4}>
          <Item>

          <CardMedia
                  component="img"
                  height="412"
                  image={D_img}
                  alt="green iguana"
                />
          <Typography gutterBottom variant="h5" component="div">
            Donors List
          </Typography>

          <Typography variant="body2" color="text.secondary">
          Someone is willing to Donate Blood Somewhere
          </Typography>
          <br></br>
          <Link to="/userdonorlist" className="btn btn-default border  rounded-50 text-decoration-none">
       VIEW
        </Link> 
        <br></br><br></br><br></br>


          </Item>
        </Grid>

         &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;



        <Grid item xs={4}>
          <Item>
          <CardMedia
                  component="img"
                  height="404"
                  image={U_img}
                  alt="green iguana"
                />
          <Typography gutterBottom variant="h6" component="div">
           <br></br>
            {/* Email : {location.state.id} */}
          </Typography>
          <br></br>

          <Button variant='contained' color='error'> <Link to="/login" className=" rounded-50 text-decoration-none">Log Out</Link>
          
          </Button><br></br><br></br><br></br>

          </Item>
        </Grid>
      
      </Grid>
    </Box>
      
      
 
    </div>
  )
}

export default Userview