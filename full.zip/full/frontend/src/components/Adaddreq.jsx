import { Button, TextField } from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Navigate, useLocation, useNavigate } from "react-router-dom";

const Adaddreq = () => {


  var [inputs, setInputs] = useState({ rname: "", rage: "", rblood: "", remail: "" , rphone: ""});
  var location = useLocation();
  var navigate = useNavigate()
  console.log("loc", location.state);

  const inputHandler = (e) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
    console.log(inputs);
  };

  const addHandler = () => {
  
        axios
        .post("http://localhost:3002/addr", inputs)
        .then((res) => {
          console.log(res);
          alert(res.data.message);
          navigate('/addash')
        })
        .catch((err) => {
          console.log(err);
        });
    
  };
  useEffect(() => {
    if (location.state !== null) {
      setInputs({
        ...inputs,
        rname: location.state.val.name,
        rage: location.state.val.age,
        rblood: location.state.val.blood,
       
        remail: location.state.val.email,
        rphone: location.state.val.phone,
      });
    }
  }, []);


  return (
    
<div style={{ marginTop: "3%", textAlign: "center" }}>
    <h1>Add Request</h1><br></br>
  <TextField
    variant="outlined"
    label="Name"
    onChange={inputHandler}
    name="rname"
    value={inputs.rname}
  />
  <br />
  <br />
  <TextField
    variant="outlined"
    label="Age"
    onChange={inputHandler}
    name="rage"
    value={inputs.rage}
  />
  <br />
  <br />
  <TextField
    variant="outlined"
    label="Email Id"
    onChange={inputHandler}
    name="remail"
    value={inputs.remail}
  />
  <br />
  <br />
  <TextField
    variant="outlined"
    label="Phone Number"
    onChange={inputHandler}
    name="rphone"
    value={inputs.rphone}
  />
  <br />
  <br />
  <TextField
    variant="outlined"
    label="Blood Group"
    onChange={inputHandler}
    name="rblood"
    value={inputs.rblood}
  />
  <br />
  <br />

  <Button variant="contained" color="success" onClick={addHandler}>
    Add
  </Button>
</div>



  )
}

export default Adaddreq