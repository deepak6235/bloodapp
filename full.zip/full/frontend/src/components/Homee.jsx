import React from 'react';
import { Slide } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'


import blood_logo from "./img/blood1.jpg"
import  blood_loogo from './img/blood2.jpg' 
import bloood_logo from './img/blood4.jpg'
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { Button } from '@mui/material';




const Example = () => {
    

    return (
       
           
          
        <Slide>
           

              <div style ={{paddingTop:"80px",paddingBottom:"80px"}}>
              <Typography><b><h4>WELCOME TO BLOOD ZONE </h4></b></Typography>
                <br></br>
            <div className="each-slide-effects">
            <img src={blood_logo} alt="" height="400px" Width="400px" />
                   <Typography><h5>"Donate blood, save lives. ...</h5></Typography>
                
            </div>
           </div>
           <div style ={{paddingTop:"80px"}}>
    
           <br></br>
            <div className="each-slide-effect">
          
                <img src={blood_loogo} alt="" height="400px" Width="400px"/>
                <br></br>
               <Typography><h5>"A single pint can save three lives, a single gesture can create a million smiles."</h5></Typography>
                
            </div>
            </div>
            <div style ={{paddingTop:"80px"}}>
           
            <br></br>
            <div className="each-slide-effectss">
            
            <img src={bloood_logo} alt=""  height="400px" Width="400px"/>
            <Typography><h5>"Your blood donation is a gift straight from the heart."</h5></Typography>  
         
            </div>
                    </div>
         
        
        </Slide>
        );
       
    };


        

    
        
     

       


export default Example;
   
  

