
import './App.css';
import Appbar from './components/Appbar';
import 'bootstrap/dist/css/bootstrap.min.css'
import { Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import Sign from './components/Sign';
import Homee from './components/Homee';
import Dash from './components/Dash';
import Adlogin from './components/Adlogin';
import Adsign from './components/Adsign';
import Addash from './components/Addash';
import Userview from './components/Userview';
import Donor from './components/Donor';
import Adminview from './components/Adminview';
import Admindonor from './components/Admindonor';
import Adupdate from './components/Adupdate';
import Adrequp from './components/Adrequp';
import Adadddonar from './components/Adadddonar';
import Adaddreq from './components/Adaddreq';
import Userdonorlist from './components/Userdonorlist';





function App() {
  
  return (
    
    <div className="App">
 

<Appbar/>
<Routes>


  {/* homepage */}
  <Route path='/' element={<Homee/>}/>


{/* user login */}
  <Route path='/login' element={<Login/>}/>



  {/* user register */}
  <Route path='/sign' element={<Sign/>}/>


  {/* blood request form */}
  <Route path='/dash' element={<Dash/>}/>
  

  {/* admin login */}
  
  <Route path='/adlogin' element={<Adlogin/>}/>

{/* admin request list */}

  <Route path='/addash' element={<Addash/>}/>

{/* admin registration*/}

  <Route path='/adsign' element={<Adsign/>}/>

{/* user dashboard */}

  <Route path='/userview' element={<Userview/>}/>
{/* 
user donate form */}
  <Route path='/donor' element={<Donor/>}/>


  {/* admin dashboard */}
  <Route path='/adminview' element={<Adminview/>}/>
  



  
  <Route path='/admindonor' element={<Admindonor/>}/>


  {/* admin donor update list */}
  <Route path='/adupdated' element={<Adupdate/>}/>



{/* admin request update list  */}
  <Route path='/adupdater' element={<Adrequp/>}/>

  {/* admin add donor */}
  <Route path='/adadddonor' element={<Adadddonar/>}/>

  {/* admin add request */}
  <Route path='/adaddreq' element={<Adaddreq/>}/>

   {/* user donor list view */}
   <Route path='/userdonorlist' element={<Userdonorlist/>}/>


</Routes>


    </div>
  );
}

export default App;
